package com.jijokjose.service;

import java.util.List;

import com.jijokjose.model.Employee;

public interface EmployeeService {
	List<Employee> getAllEmployees();
	void insertEmployee(Employee employee);
}

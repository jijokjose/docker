package com.jijokjose.dao;

import java.util.List;

import com.jijokjose.model.Employee;


public interface EmployeeDao {
	List<Employee> getAllEmployees();
	void insertEmployee(Employee employee);
}
